package turneroMedico;

import java.util.Date;
import java.util.List;

public class Medico extends Usuario {
	private String mat;
	private float costoConsulta;
	private ObraSocial obraSocial;
	private List<Turno> turnos;
	
	public Medico(int id, String name, int dni, String email, String pass, Date birth, String phone, String mat, float costoConsulta, ObraSocial obraSocial) {
		super(id, name, dni, email, pass, birth, phone);
		this.mat = mat;
		this.costoConsulta = costoConsulta;
		this.obraSocial = obraSocial;
	}

	public String getMat() {
		return mat;
	}
	
	public void setMat(String mat) {
		this.mat = mat;
	}
	
	public float getCostoConsulta() {
		return costoConsulta;
	}
	
	public void setCostoConsulta(float costoConsulta) {
		this.costoConsulta = costoConsulta;
	}
	
	public ObraSocial getObraSocial() {
		return obraSocial;
	}
	
	public void setObraSocial(ObraSocial obraSocial) {
		this.obraSocial = obraSocial;
	}
	
	public List<Turno> getTurnos() {
		return turnos;
	}
	
	public void setTurnos(List<Turno> turnos) {
		this.turnos = turnos;
	}

}
