package turneroMedico;

import java.util.Date;

public class Turno {
	private Date date;
	private Medico medico;
	private Paciente paciente;
	private Consultorio consul;
	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public Medico getMedico() {
		return medico;
	}
	
	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Consultorio getConsul() {
		return consul;
	}

	public void setConsul(Consultorio consul) {
		this.consul = consul;
	}
	
}
