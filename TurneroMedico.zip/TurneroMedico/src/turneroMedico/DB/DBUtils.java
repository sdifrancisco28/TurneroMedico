package turneroMedico.DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import turneroMedico.Exceptions.ConnectionException;
import turneroMedico.Exceptions.QueryException;
import turneroMedico.Exceptions.TransactionException;

public class DBUtils {

		private static final String DB_DRIVER = "org.h2.Driver";
		private static final String DB_URL = "jdbc:h2:C:\\Users\\Santiago Difrancisco\\Documents\\Licenciatura\\Segundo año\\Programación 3\\Tp final\\database\\db_turnero";
		private static final String DB_USER = "admin";
		private static final String DB_PASS = "admin";
		
		
		public static Connection connect() throws ConnectionException, ClassNotFoundException {
			try {
				Class.forName(DB_DRIVER);
				return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
			} catch (SQLException e) {
				throw new ConnectionException("Error al iniciar la conexión con la base", e);
			}
		}
		
		public static void closeConnection(Connection connection) throws ConnectionException {
	        try {
	            if (connection != null) {
	                connection.close();
	            }
	        } catch (SQLException e) {
	            throw new ConnectionException("Error al cerrar la conexión a la base de datos", e);
	        }
	    }
		
		public static void beginTransaction(Connection connection) throws TransactionException {
	        try {
	            connection.setAutoCommit(false);
	        } catch (SQLException e) {
	            throw new TransactionException("Error al comenzar la transacción", e);
	        }
	    }

	    public static void commitTransaction(Connection connection) throws TransactionException {
	        try {
	            connection.commit();
	        } catch (SQLException e) {
	            throw new TransactionException("Error al confirmar la transacción", e);
	        }
	    }

	    public static void rollbackTransaction(Connection connection) throws TransactionException {
	        try {
	            connection.rollback();
	        } catch (SQLException e) {
	            throw new TransactionException("Error al cancelar la transacción", e);
	        }
	    }
	    
	    public static ResultSet executeQuery(Connection connection, String sql) throws QueryException {
	        Statement statement = null;
	        try {
	            statement = connection.createStatement();
	            return statement.executeQuery(sql);
	        } catch (SQLException e) {
	            throw new QueryException("Error al ejecutar consulta", e);
	        }
	       }
	        
	        
	        public static String execute(Connection connection, String sql) throws QueryException {
	            Statement statement = null;
	            try {
	                statement = connection.createStatement();
	                statement.execute(sql);
	            } catch (SQLException e) {
	            	try {
	                    connection.rollback(); // hacer rollback en caso de error
	                } catch (SQLException e1) {
	                    throw new QueryException("Error al hacer rollback", e1);
	                }
	                throw new QueryException("Error al ejecutar consulta", e);
	            } finally {
	                try {
	                    if (statement != null) {
	                        statement.close();
	                    }
	                } catch (SQLException e) {
	                    throw new QueryException("Error al cerrar statement", e);
	                }
	            }
	            return "Ok";
	        }
}
