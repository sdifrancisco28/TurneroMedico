package turneroMedico.DB;

import java.sql.SQLException;
import java.util.List;

import turneroMedico.Administrador;
import turneroMedico.Medico;
import turneroMedico.Paciente;
import turneroMedico.Usuario;
import turneroMedico.Exceptions.ConnectionException;
import turneroMedico.Exceptions.QueryException;
import turneroMedico.Exceptions.TransactionException;

public interface DatabaseDAO {

	void creaTablaUsuarios() throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException;
	
	void eliminarTablaUsuarios() throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException;
	
	void agregarMedico(Medico m) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException;
	
	void agregarPaciente(Paciente p) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException;
	
	void eliminarMedico(String id) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException;
	
	void eliminarPaciente(String id) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException;
	
	Medico mostrarMedico(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException;
	
	Paciente mostrarPaciente(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException;
	
	Administrador mostrarAdministrador(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException;
	
	List<Medico> listAllMedicos() throws ConnectionException, ClassNotFoundException, QueryException, SQLException;

	List<Paciente> listAllPacientes() throws ConnectionException, ClassNotFoundException, QueryException, SQLException;
	
	boolean checkAccount(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException;
	
	Usuario getAccount(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException;
	
	int getAccountID(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException;
	
	String getAccountTable(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException;
}
