package turneroMedico.DB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import turneroMedico.Administrador;
import turneroMedico.Medico;
import turneroMedico.ObraSocial;
import turneroMedico.Paciente;
import turneroMedico.Usuario;
import turneroMedico.Exceptions.ConnectionException;
import turneroMedico.Exceptions.QueryException;
import turneroMedico.Exceptions.TransactionException;

public class DatabaseDAOH2Impl implements DatabaseDAO{

	public void creaTablaUsuarios() throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException  {
	    Connection connection = null;
	    String sql = "CREATE TABLE usuarios_data(id INTEGER NOT NULL auto_increment, nombre VARCHAR(256), apellido VARCHAR(256) NOT NULL, dni VARCHAR(256), email VARCHAR(256), PRIMARY KEY(id))";
	    
	    try {
	        connection = DBUtils.connect();
	        DBUtils.execute(connection, sql);
	        DBUtils.beginTransaction(connection);
	        DBUtils.commitTransaction(connection);
	    } catch (ConnectionException e) {
	        throw e;
	    } finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
	}



	public void eliminarTablaUsuarios() throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException {
		Connection connection = null;
	    String sql = "DROP TABLE usuarios_data";
	try {
	    connection = DBUtils.connect();
	    DBUtils.execute(connection, sql);
	    DBUtils.beginTransaction(connection);
	    DBUtils.commitTransaction(connection);
	} catch (ConnectionException e) {
	    throw e;
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
	}

	@Override
	public void agregarMedico(Medico m) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException {
	    Connection connection = null;
	    String name = m.getName();
	    int dni = m.getDni();
	    String email = m.getEmail();
	    String pass = m.getPass();
	    Date birth = m.getBirth();
	    String phone = m.getPhone();
	    String mat = m.getMat();
	    float costoConsulta = m.getCostoConsulta();
	    
	    String sql = "INSERT INTO Medico (NAME, DNI, EMAIL, PASS, BIRTH, PHONE, MAT, PRICE) VALUES ('" + name + "',  '" + dni + "', '" + email + "', '" + pass + "', '" + birth + "', '" + phone + "', '" + mat + "', '" + costoConsulta + "')";
	try {
	    connection = DBUtils.connect();
	    DBUtils.execute(connection, sql);
	    DBUtils.beginTransaction(connection);
	    DBUtils.commitTransaction(connection);
	} catch (ConnectionException e) {
	    throw e;
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
	}
	
	@Override
	public void agregarPaciente(Paciente p) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException {
	    Connection connection = null;
	    String name = p.getName();
	    int dni = p.getDni();
	    String email = p.getEmail();
	    String pass = p.getPass();
	    Date birth = p.getBirth();
	    String phone = p.getPhone();
	    String address = p.getAddress();
	    
	    String sql = "INSERT INTO Paciente (NAME, DNI, EMAIL, PASS, BIRTH, PHONE, ADDRESS) VALUES ('" + name + "',  '" + dni + "', '" + email + "', '" + pass + "', '" + birth + "', '" + phone + "', '" + address + "')";
	try {
	    connection = DBUtils.connect();
	    DBUtils.execute(connection, sql);
	    DBUtils.beginTransaction(connection);
	    DBUtils.commitTransaction(connection);
	} catch (ConnectionException e) {
	    throw e;
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
	}
	
	@Override
	public void eliminarMedico(String id) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException {
		Connection connection = null;
		String sql = "DELETE FROM MEDICO WHERE ID = " + id; 
	try {
	    connection = DBUtils.connect();
	    DBUtils.execute(connection, sql);
	    DBUtils.beginTransaction(connection);
	    DBUtils.commitTransaction(connection);
	} catch (ConnectionException e) {
	    throw e;
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
	}
	
	@Override
	public void eliminarPaciente(String id) throws QueryException, ConnectionException, SQLException, ClassNotFoundException, TransactionException {
		Connection connection = null;
		String sql = "DELETE FROM MEDICO WHERE ID = " + id; 
	try {
	    connection = DBUtils.connect();
	    DBUtils.execute(connection, sql);
	    DBUtils.beginTransaction(connection);
	    DBUtils.commitTransaction(connection);
	} catch (ConnectionException e) {
	    throw e;
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
	}
	
	public Medico mostrarMedico(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException{
		Connection connection = DBUtils.connect();
		String sql = "SELECT * FROM MEDICO WHERE ID = " + id;
	try {
	    ResultSet rs = DBUtils.executeQuery(connection, sql);
	    if (rs.next()) {
	    	int idrs = rs.getInt("id");
	    	String name = rs.getString("name");
	    	int dni = rs.getInt("identity_number");
	    	String email = rs.getString("email");
	    	String pass = rs.getString("password");
	    	Date birth = rs.getDate("birth");
		    String phone = rs.getString("phone");
		    String mat = rs.getString("mat");
		    float costoConsulta = rs.getFloat("price");
		    int idObraSocial = rs.getInt("id_obra_social");
		    
		    ObraSocial os = new ObraSocial();
		    os = os.obtenerObraSocial(idObraSocial);
		
		    Medico m = new Medico(idrs, name, dni, email, pass, birth, phone, mat, costoConsulta, os);
	    	return m;
	    }
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return null;
	}
	
	public Paciente mostrarPaciente(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException{
		Connection connection = DBUtils.connect();
		String sql = "SELECT * FROM PACIENTE WHERE ID = " + id;
	try {
	    ResultSet rs = DBUtils.executeQuery(connection, sql);
	    if (rs.next()) {
	    	int idrs = rs.getInt("id");
	    	String name = rs.getString("name");
	    	int dni = rs.getInt("identity_number");
	    	String email = rs.getString("email");
	    	String pass = rs.getString("password");
	    	Date birth = rs.getDate("birth");
		    String phone = rs.getString("phone");
		    String address = rs.getString("address");
		    int idObraSocial = rs.getInt("id_obra_social");
		    
		    ObraSocial os = new ObraSocial();
		    os = os.obtenerObraSocial(idObraSocial);
		
		    Paciente p = new Paciente(idrs, name, dni, email, pass, birth, phone, address, os);
	    	return p;
	    }
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return null;
	}
	
	public Administrador mostrarAdministrador(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException{
		Connection connection = DBUtils.connect();
		String sql = "SELECT * FROM ADMINISTRADOR WHERE ID = " + id;
	try {
	    ResultSet rs = DBUtils.executeQuery(connection, sql);
	    if (rs.next()) {
			String name = rs.getString("NAME");
			int idNumber = rs.getInt("IDENTITY_NUMBER");
			String email = rs.getString("EMAIL");
			String password = rs.getString("PASSWORD");
			Date birth = rs.getDate("BIRTH");
			String phone = rs.getString("PHONE");
		   
			Administrador a = new Administrador(id, name, idNumber, email, password, birth, phone);
	    	return a;
	    }
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return null;
	}

	public Usuario getAccount(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException {
		Connection connection = DBUtils.connect();
		int iduser = 0;
		String table = null;
		String sql = "SELECT ID, 'MEDICO' AS tabla FROM MEDICO WHERE Email = '" + email + "' AND Password = '"+ password + "'"
				+ " UNION"
				+ " SELECT ID, 'PACIENTE' AS tabla FROM PACIENTE WHERE Email = '" + email + "' AND Password = '" + password + "'"
				+ " UNION"
				+ " SELECT ID, 'ADMINISTRADOR' AS tabla FROM ADMINISTRADOR WHERE Email = '" + email + "' AND Password = '" + password + "'";
		
		try {
			ResultSet rs = DBUtils.executeQuery(connection, sql);
			iduser = rs.getInt("ID");
			table = rs.getString("tabla");
			
			if(table == "ADMINISTRADOR") {
				Administrador a = mostrarAdministrador(iduser);
				return a;
			} else if(table == "MEDICO") {
				Medico m = mostrarMedico(iduser);
				return m;
			} else if(table == "PACIENTE") {
				Paciente u = mostrarPaciente(iduser);
				return u;
			}
		}finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return null;
	}
	
	@Override
	public List<Medico> listAllMedicos() throws ConnectionException, ClassNotFoundException, QueryException, SQLException {
		Connection connection = DBUtils.connect();
		List<Medico> list = new ArrayList<>();
		String sql = "SELECT * FROM usuarios_data";
		
		try {
			ResultSet rs = DBUtils.executeQuery(connection, sql);
			
			while (rs.next()) {
				int idrs = rs.getInt("id");
		    	String name = rs.getString("name");
		    	int dni = rs.getInt("identity_number");
		    	String email = rs.getString("email");
		    	String pass = rs.getString("password");
		    	Date birth = rs.getDate("birth");
			    String phone = rs.getString("phone");
			    String mat = rs.getString("mat");
			    float costoConsulta = rs.getFloat("price");
			    int idObraSocial = rs.getInt("id_obra_social");
			    
			    ObraSocial os = new ObraSocial();
			    os = os.obtenerObraSocial(idObraSocial);
			    Medico m = new Medico(idrs, name, dni, email, pass, birth, phone, mat, costoConsulta, os);
	        	list.add(m);
			}
		}finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return list;
	}
	
	
	@Override
	public List<Paciente> listAllPacientes() throws ConnectionException, ClassNotFoundException, QueryException, SQLException {
		Connection connection = DBUtils.connect();
		List<Paciente> list = new ArrayList<>();
		String sql = "SELECT * FROM usuarios_data";
		
		try {
			ResultSet rs = DBUtils.executeQuery(connection, sql);
			
			while (rs.next()) {
				int idrs = rs.getInt("id");
		    	String name = rs.getString("name");
		    	int dni = rs.getInt("identity_number");
		    	String email = rs.getString("email");
		    	String pass = rs.getString("password");
		    	Date birth = rs.getDate("birth");
			    String phone = rs.getString("phone");
			    String address = rs.getString("address");
			    int idObraSocial = rs.getInt("id_obra_social");
			    
			    ObraSocial os = new ObraSocial();
			    os = os.obtenerObraSocial(idObraSocial);
			
			    Paciente p = new Paciente(idrs, name, dni, email, pass, birth, phone, address, os);
	        	list.add(p);
			}
		}finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return list;
	}
	
	
	public boolean checkAccount(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException {
		Connection connection = DBUtils.connect();
		boolean exist = false;
		String sql = "SELECT ID, 'MEDICO' AS tabla FROM MEDICO WHERE Email = '" + email + "' AND Password = '"+ password + "'"
				+ " UNION"
				+ " SELECT ID, 'PACIENTE' AS tabla FROM PACIENTE WHERE Email = '" + email + "' AND Password = '" + password + "'"
				+ " UNION"
				+ " SELECT ID, 'ADMINISTRADOR' AS tabla FROM ADMINISTRADOR WHERE Email = '" + email + "' AND Password = '" + password + "'";
		
		try {
			ResultSet rs = DBUtils.executeQuery(connection, sql);
			exist = rs.next();
		}finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return exist;
	}
	
	public int getAccountID(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException {
		Connection connection = DBUtils.connect();
		int id = 0;
		String sql = "SELECT ID, 'MEDICO' AS tabla FROM MEDICO WHERE Email = '" + email + "' AND Password = '"+ password + "'"
				+ " UNION"
				+ " SELECT ID, 'PACIENTE' AS tabla FROM PACIENTE WHERE Email = '" + email + "' AND Password = '" + password + "'"
				+ " UNION"
				+ " SELECT ID, 'ADMINISTRADOR' AS tabla FROM ADMINISTRADOR WHERE Email = '" + email + "' AND Password = '" + password + "'";
		
		try {
			ResultSet rs = DBUtils.executeQuery(connection, sql);
			if (rs.next()) {
				id = rs.getInt("id");
			}
		}finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return id;
	}
	
	public String getAccountTable(String email, String password) throws ConnectionException, ClassNotFoundException, QueryException, SQLException {
		Connection connection = DBUtils.connect();
		String table = null;
		String sql = "SELECT ID, 'MEDICO' AS tabla FROM MEDICO WHERE Email = '" + email + "' AND Password = '"+ password + "'"
				+ " UNION"
				+ " SELECT ID, 'PACIENTE' AS tabla FROM PACIENTE WHERE Email = '" + email + "' AND Password = '" + password + "'"
				+ " UNION"
				+ " SELECT ID, 'ADMINISTRADOR' AS tabla FROM ADMINISTRADOR WHERE Email = '" + email + "' AND Password = '" + password + "'";
		
		try {
			ResultSet rs = DBUtils.executeQuery(connection, sql);
			if (rs.next()) {
				table = rs.getString("tabla");
			}
		}finally {
	        try {
	        	DBUtils.closeConnection(connection);
	        } catch (ConnectionException e) {
	            throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return table;
	}
	
	
}
