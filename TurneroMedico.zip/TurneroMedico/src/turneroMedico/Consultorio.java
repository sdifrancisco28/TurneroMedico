package turneroMedico;

public class Consultorio {
	private String name;
	private String address;
	private boolean available;
	
	public Consultorio(String name, String address, boolean available) {
		this.name = name;
		this.address = address;
		this.available = available;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
