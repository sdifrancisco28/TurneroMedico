package turneroMedico;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import turneroMedico.DB.DBUtils;
import turneroMedico.Exceptions.ConnectionException;
import turneroMedico.Exceptions.QueryException;

public class ObraSocial {
	private int id;
	private String name;
	private String address;
	
	public ObraSocial() {
		
	}
	
	public ObraSocial(int id, String name, String address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}
	
	public String getNombre() {
		return name;
	}
	public void setNombre(String nombre) {
		this.name = nombre;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public ObraSocial obtenerObraSocial(int id) throws QueryException, ClassNotFoundException, ConnectionException, SQLException {
		Connection connection = DBUtils.connect();
		String sql = "SELECT * FROM OBRA_SOCIAL WHERE ID = " + id;
	try {
	    ResultSet rs = DBUtils.executeQuery(connection, sql);
	    if (rs.next()) {
	    	int idos = rs.getInt("id");
	    	String name = rs.getString("name");
	    	String address = rs.getString("address");
		    
		    ObraSocial os = new ObraSocial(idos, name, address);
	    	
	    	return os;
	    }
	} finally {
	    try {
	    	DBUtils.closeConnection(connection);
	    } catch (ConnectionException e) {
	        throw new ConnectionException("Error al cerrar la conexión", e);
	        }
	    }
		return null;
	}
	
}
