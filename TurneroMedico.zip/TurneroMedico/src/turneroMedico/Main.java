package turneroMedico;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;


import turneroMedico.Frames.Login;

public class Main {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Login - Turnero médico");
		frame.getContentPane().add(new Login());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = screensize.width / 2;
		int height = screensize.height / 2;
		frame.setSize(width, height);
	}
}
