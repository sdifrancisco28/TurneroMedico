package turneroMedico.Frames;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Random;

import javax.print.DocFlavor.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import turneroMedico.Usuario;
import turneroMedico.DB.DatabaseDAO;
import turneroMedico.DB.DatabaseDAOH2Impl;
import turneroMedico.Exceptions.ConnectionException;
import turneroMedico.Exceptions.QueryException;

public class Login extends JPanel implements ActionListener {
	private JLabel userLabel;
	private JLabel passLabel;
	private JTextField userText;
	private JTextField passText;
	private JButton okButton;
	private JButton exitButton;
	private ImageIcon logoImage;
	private JLabel errorLabel;
	private JLabel errorLabel2;
	
	public Login() {
		super();
		createLogin();
	}
	
	private void createLogin() {
		userLabel = new JLabel("Usuario");
		userText = new JTextField(10);
		passLabel = new JLabel("Contraseña");
		passText = new JPasswordField(10);
		okButton = new JButton("Iniciar sesión");
		exitButton = new JButton("Salir");
		errorLabel = new JLabel("¡Error! El usuario o contraseña");
		errorLabel.setVisible(false);
		errorLabel.setForeground(Color.RED);
		errorLabel2 = new JLabel("ingresados son incorrectos.");
		errorLabel2.setVisible(false);
		errorLabel2.setForeground(Color.RED);
		okButton.addActionListener(this);
		exitButton.addActionListener(this);
		
		Dimension buttonSize = new Dimension(190, 25);
		okButton.setPreferredSize(buttonSize);
		exitButton.setPreferredSize(buttonSize);
		Font frameFont = new Font("Arial", Font.BOLD, 15);
		Font userFont = new Font("Arial", 0, 15);
		Font errorFont = new Font("Arial", 0, 13);
		okButton.setFont(frameFont);
		exitButton.setFont(frameFont);
		userLabel.setFont(frameFont);
		userText.setFont(userFont);
		userText.setPreferredSize(buttonSize);
		passLabel.setFont(frameFont);
		passText.setFont(userFont);
		passText.setPreferredSize(buttonSize);
		errorLabel.setFont(errorFont);
		errorLabel2.setFont(errorFont);
		
		logoImage = new ImageIcon("R:\\Archivos de Programa\\Eclipse\\eclipse-workspace\\TurneroMedico\\hospital.png");
		Image scaledImage = logoImage.getImage().getScaledInstance(140, 140, Image.SCALE_SMOOTH);
		logoImage = new ImageIcon(scaledImage);
        JLabel logoLabel = new JLabel(logoImage);
        
       
        JPanel mainPanel = new JPanel(new GridBagLayout());
        
		GridBagConstraints gbcLogo = new GridBagConstraints();
        gbcLogo.gridx = 0;
        gbcLogo.gridy = 1;
        gbcLogo.gridwidth = 2;
        gbcLogo.anchor = GridBagConstraints.CENTER;
        gbcLogo.insets = new Insets(80, 3, 2, 5);
        mainPanel.add(logoLabel, gbcLogo);
        
        GridBagConstraints gbcLabels = new GridBagConstraints();
        gbcLabels.gridx = 0;
        gbcLabels.gridy = 2;
        gbcLabels.anchor = GridBagConstraints.FIRST_LINE_START;
        gbcLabels.insets = new Insets(5, 3, 2, 5);
        mainPanel.add(userLabel, gbcLabels);		
        
        GridBagConstraints gbcFields = new GridBagConstraints();
        gbcFields.gridx = 0;
        gbcFields.gridy = 3;
        gbcFields.gridwidth = 2;
        gbcFields.fill = GridBagConstraints.HORIZONTAL;
        gbcFields.insets = new Insets(2, 0, 5, 5);
        mainPanel.add(userText, gbcFields);
        
        GridBagConstraints gbcPassLabels = new GridBagConstraints();
        gbcPassLabels.gridx = 0;
        gbcPassLabels.gridy = 5;
        gbcPassLabels.anchor = GridBagConstraints.FIRST_LINE_START;
        gbcPassLabels.insets = new Insets(7, 3, 2, 5);
        mainPanel.add(passLabel, gbcPassLabels);		
        
        GridBagConstraints gbcPassFields = new GridBagConstraints();
        gbcPassFields.gridx = 0;
        gbcPassFields.gridy = 6;
        gbcPassFields.gridwidth = 2;
        gbcPassFields.fill = GridBagConstraints.HORIZONTAL;
        gbcPassFields.insets = new Insets(2, 0, 5, 5);       
        mainPanel.add(passText, gbcPassFields);		
		
        GridBagConstraints gbcButtons = new GridBagConstraints();
        gbcButtons.gridx = 0;
        gbcButtons.gridy = 7;
        gbcButtons.gridwidth = 2;
        gbcButtons.anchor = GridBagConstraints.CENTER;
        gbcButtons.insets = new Insets(5, 0, 5, 0);
        mainPanel.add(okButton, gbcButtons);
        
        GridBagConstraints gbcCancelButton = new GridBagConstraints();
        gbcCancelButton.gridx = 0;
        gbcCancelButton.gridy = 8;
        gbcCancelButton.gridwidth = 2;
        gbcCancelButton.anchor = GridBagConstraints.CENTER;
        gbcCancelButton.insets = new Insets(5, 0, 5, 0);
        mainPanel.add(exitButton, gbcCancelButton);
        
        GridBagConstraints gbcErrorLabel = new GridBagConstraints();
        gbcErrorLabel.gridx = 0;
        gbcErrorLabel.gridy = 9;
        gbcErrorLabel.gridwidth = 2;
        gbcErrorLabel.anchor = GridBagConstraints.CENTER;
        gbcErrorLabel.insets = new Insets(5, 0, 2, 0);
        mainPanel.add(errorLabel, gbcErrorLabel);
        
        GridBagConstraints gbcErrorLabel2 = new GridBagConstraints();
        gbcErrorLabel2.gridx = 0;
        gbcErrorLabel2.gridy = 10;
        gbcErrorLabel2.gridwidth = 2;
        gbcErrorLabel2.anchor = GridBagConstraints.CENTER;
        gbcErrorLabel2.insets = new Insets(2, 0, 5, 0);
        mainPanel.add(errorLabel2, gbcErrorLabel2);
        
		add(mainPanel);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == okButton) {
			String user = userText.getText();
			String pass = passText.getText();
			int idUser = 0;
			String idTable = null;
			
			if (user.isEmpty() || pass.isEmpty()) {
				errorLabel.setVisible(true);
				errorLabel2.setVisible(true);
			} else {
			
				DatabaseDAO dbdao = new DatabaseDAOH2Impl();
				
				
				try {
					idUser = dbdao.getAccountID(user, pass);
					idTable = dbdao.getAccountTable(user, pass);
				} catch (ConnectionException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (QueryException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(idUser != 0 && idTable != null) {
					JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
			        frame.dispose();
			        //System.out.println(idUser + idTable);
			        MainFrame mainFrame = new MainFrame(idUser, idTable);
			        
				} else {
					errorLabel.setVisible(true);
					errorLabel2.setVisible(true);
				}
			
			}
		
		
		} else if(e.getSource() == exitButton) {
			JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            frame.dispose();
		}
	}
	
}
