package turneroMedico.Frames;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import turneroMedico.Administrador;
import turneroMedico.Medico;
import turneroMedico.Paciente;
import turneroMedico.DB.DatabaseDAO;
import turneroMedico.DB.DatabaseDAOH2Impl;
import turneroMedico.Exceptions.ConnectionException;
import turneroMedico.Exceptions.QueryException;

public class MainFrame extends JFrame implements ActionListener {
	private JButton calendarioButton;
	private JButton crearTurnoButton;
	private JButton administradorButton;
	private JButton salirButton;
	Administrador a = null;
	Paciente p = null;
	Medico m = null;

	
    public MainFrame(int idUser, String table) {
        setTitle("Menú Principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(400, 300));
        initComponents(idUser, table);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    public void closeFrame() {
    	dispose();
    }

    private void initComponents(int idUser, String table) {    	
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        calendarioButton = createButton("Calendario");
        crearTurnoButton = createButton("Crear Turno");
        administradorButton = createButton("Administrador");
        salirButton = createButton("Salir");

        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        buttonPanel.add(calendarioButton);
        buttonPanel.add(crearTurnoButton);
        buttonPanel.add(administradorButton);
        buttonPanel.add(salirButton);
        
        calendarioButton.addActionListener(this);
        crearTurnoButton.addActionListener(this);
        administradorButton.addActionListener(this);
        salirButton.addActionListener(this);
        
        
        DatabaseDAO dbdao = new DatabaseDAOH2Impl();
        
        if(table.equals("ADMINISTRADOR")) {
        	try {
				a = dbdao.mostrarAdministrador(idUser);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (QueryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        	
        } else if(table.equals("PACIENTE")) {
        	try {
				p = dbdao.mostrarPaciente(idUser);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (QueryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	administradorButton.setVisible(false);
        
        } else if (table.equals("MEDICO")) {
        	try {
				m = dbdao.mostrarMedico(idUser);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (QueryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	administradorButton.setVisible(false);
        }
        

        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        add(mainPanel);

    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setPreferredSize(new Dimension(150, 60));
        return button;
    }

    @Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == administradorButton) {
			System.out.println("Ok");		
		} else if(e.getSource() == salirButton) {
			closeFrame();
		}		
	}
    
}