package turneroMedico.Frames;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import turneroMedico.Medico;


public class MedicoTableModel extends AbstractTableModel {

	/**	
	 * Indices de columnas
	 */
	//private static final int COLUMN
	private static final int COLUMN_NAME = 0;
	private static final int COLUMN_DNI = 1;
	//private static final int COLMU = 2;
	private static final int COLUMN_EMAIL = 3;
	
	/**	
	 * Nombre de columnas
	 */	
	private String[] columnName = {"Nombre", "Apellido", "Dni", "Email"};
	
	/**	
	 * Tipos de cada columna
	 */
	
	private Class[] columnType = {String.class, String.class, String.class, String.class};
	
	/**	
	 * Lista con los datos a mostrar
	 */
	
	private List<Medico> data;
	
	/**	
	 * Constructor vacío
	 */
	public MedicoTableModel() {
		data = new ArrayList<Medico>();
	}
	
	/**	
	 * Contructor inicial
	 */
	
	public MedicoTableModel(List<Medico> dataInitial) {
		data = dataInitial;
	}
	
	/**	
	 * Métodos que se pisan
	 */

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return data.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columnName.length;
	}

	@Override
	public String getColumnName(int col) {
		// TODO Auto-generated method stub
		return columnName[col];
	}
	
	@Override
	public Class getColumnClass(int col) {
		// TODO Auto-generated method stub
		return columnType[col];
	}
	
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		
		Medico m = data.get(rowIndex);
		
		Object result = null;
		switch(columnIndex) {
		case COLUMN_NAME:
			result = m.getName();
			break;
		case COLUMN_DNI:
			result = m.getDni();
			break;
//		case COLUMN_DNI:
//			result = m.getDni();
//			break;
		case COLUMN_EMAIL:
			result = m.getEmail();
			break;
		default:
			result = new String("");			
		}
		
		return result;
	}
	
	
	/**	
	 * Getters y setters de las filas
	 */	
	
	public List<Medico> getData() {
		return data;
	}

	public void setData(List<Medico> data) {
		this.data = data;
	}
}
