package turneroMedico;

import java.util.Date;
import java.util.List;

public class Paciente extends Usuario {
	private String address;
	private ObraSocial obraSocial;
	private List<Turno> turnos;
	
	public Paciente(int id, String name, int dni, String email, String pass, Date birth, String phone, String address, ObraSocial obraSocial) {
		super(id, name, dni, email, pass, birth, phone);
		this.obraSocial = obraSocial;
		this.address = address;
	}
	
	public ObraSocial getObraSocial() {
		return obraSocial;
	}
	public void setObraSocial(ObraSocial obraSocial) {
		this.obraSocial = obraSocial;
	}
	
	public List<Turno> getTurnos() {
		return turnos;
	}
	public void setTurnos(List<Turno> turnos) {
		this.turnos = turnos;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}

