package turneroMedico;

import java.sql.Date;

public abstract class Usuario {
	private int id;
	private String name;
	private int dni;
	private String email;
	private String pass;
	private Date birth;
	private String phone;
	
	public Usuario(int id, String name, int dni, String email, String pass, java.util.Date birth, String phone) {
		this.id = id;
		this.name = name;
		this.dni = dni;
		this.email = email;
		this.pass = pass;
		this.birth = (Date) birth;
		this.phone = phone;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getDni() {
		return dni;
	}
	public void setDni(int dni) {
		this.dni = dni;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
}
