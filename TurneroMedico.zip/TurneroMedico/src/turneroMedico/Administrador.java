package turneroMedico;

import java.util.Date;
import java.util.Random;

public class Administrador extends Usuario {

	public Administrador(int id, String name, int dni, String email, String pass, Date birth, String phone) {
		super(id, name, dni, email, pass, birth, phone);
	}
	
	public void createMedico(int id, String name, int dni, String email, String pass, Date birth, String phone, String mat, float costoConsulta, ObraSocial obraSocial) {
		Medico m = new Medico(id, name, dni, email, pass, birth, phone, mat, costoConsulta, obraSocial);
	}
	
	public void createPaciente(int id, String name, int dni, String email, String pass, Date birth, String phone, String address, ObraSocial obraSocial) {
		Paciente p = new Paciente(id, name, dni, email, pass, birth, phone, address, obraSocial);
	}
	
	public void createConsultorio(String name, String address, boolean available) {
		Consultorio c = new Consultorio(name, address, available);
	}
	
	public void createObraSocial(int id, String name, String address) {
		ObraSocial os = new ObraSocial(id, name, address);
	}
	
	public String cleanPassword(Usuario user) {
		Random r = new Random();
		int x = r.nextInt(100);
		
		user.setPass("Blanqueo" + x);
		
		return user.getPass();
	}
}


