package turneroMedico.Exceptions;


public class ConnectionException extends turneroMedico.Exceptions.DataAccessException{
	public ConnectionException(String message) {
		super(message);
	}
	
	public ConnectionException(String message, Throwable cause) {
		super(message, cause);
	}
}
