package turneroMedico.Exceptions;


public class TransactionException extends DataAccessException {
	public TransactionException(String message) {
		super(message);
	}
	
	public TransactionException(String message, Throwable cause) {
		super(message, cause);
	}

}
