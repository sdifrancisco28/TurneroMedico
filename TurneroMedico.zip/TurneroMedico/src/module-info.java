/**
 * 
 */
/**
 * @author Santiago Difrancisco
 *
 */
module TurneroMedico {
	requires java.sql;
	requires java.desktop;
}